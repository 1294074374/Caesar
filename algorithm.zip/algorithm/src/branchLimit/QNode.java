package branchLimit;

public class QNode 
{
	QNode parent;
	boolean leftChild;
	int weight;
	QNode next;
	public QNode(){}
	public  QNode(QNode theParent,boolean theLeftChild,int theWeight)
	{
		parent=theParent;
		leftChild=theLeftChild;
		weight=theWeight;
	}
}