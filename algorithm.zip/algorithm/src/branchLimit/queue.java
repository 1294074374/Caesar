package branchLimit;

public interface queue<E>
{
	public void put(E target);
	public E remove();
	public int size();
	public boolean isEmpty();
	public E front();
}
