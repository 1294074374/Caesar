package dynamicProgramming;

public class MatrixText {
	public static void main(String agrs[]) {
		int[] p = { 10,5,2,8,4,9,10,7,6 };
		int n = p.length;
		int[][] m = new int[n][n];
		int[][] s = new int[n][n];
		Matrix m1 = new Matrix();
		m1.matrixChain(p, m, s);
//		System.out.println("�þ���׳����������˵Ĵ���:");
//		for (int i = 1; i < m.length; i++) {
//			for (int j = 1; j < m.length; j++) {
//				if (i > j) {
//					System.out.print("----" + "\t");
//				} else {
//					System.out.print(m[i][j] + "\t");
//				}
//			}
//			System.out.println();
//		}
//		System.out.println();
//		System.out.println("�þ���׳����������˵Ĵ���:");
//		for (int i = 1; i < s.length; i++) {
//			for (int j = 1; j < s.length; j++) {
//				if (i > j) {
//					System.out.print("----" + "\t");
//				} else {
//					System.out.print(s[i][j] + "\t");
//				}
//			}
//			System.out.println();
//		}
//		System.out.println();
		System.out.println("�þ���׳˵����Ž�:");
		m1.TraceBack(s, 1, n - 1);
		System.out.println("�þ���׳˵����ų˷�:");
		m1.OptimalParens(s, 1, n - 1);
	}
}
