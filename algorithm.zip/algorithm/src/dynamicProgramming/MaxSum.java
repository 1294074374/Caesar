package dynamicProgramming;

public class MaxSum {
	public void maxSumDp(int[] arr) {
		int sum = 0, b = 0, n = arr.length, bestx = 0, besty = 0;
		for (int i = 1; i <= n; i++) {
			if (b > 0) {
				b += arr[i - 1];
			} else {
				b = arr[i - 1];
				bestx = i;
			}
			if (b > sum) {
				sum = b;
				besty = i;
			}
		}
		System.out.println("��̬�滮�㷨����ֵ��" + sum);
		System.out.println("���Ž⣺" + bestx + "-->" + besty);
	}
}
