package dynamicProgramming;

public class MaxSumText {
	public static void main(String[] args) {
		int[] arr = { -2, 11, -4, 13, -5, -2 };
		System.out.println("ԭ����Ϊ:");
		for (int i = 0;i<arr.length;i++){
			System.out.print(arr[i]+ " ");
		}
		System.out.println();
		MaxSum S = new MaxSum();
		S.maxSumDp(arr);
	}
}
