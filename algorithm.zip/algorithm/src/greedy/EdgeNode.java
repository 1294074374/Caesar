package greedy;

public class EdgeNode implements Comparable{
	float weight;
	int u ,v;
	
	EdgeNode(int uu,int vv,float ww){
		u=uu;
		v=vv;
		weight=ww;
	}
	public int compareTo(Object x) {
		double xw=((EdgeNode) x).weight;
		if (weight < xw)
			return -1;
		if (weight == xw)
			return 0;
		return 1;

	}

}
