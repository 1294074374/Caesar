package greedy;

/**
 * ����װ��javaBean
 *
 * @author lenovo
 *
 */
public class Element implements Comparable {
	float w;
	int i;

	public Element(float ww, int ii) {
		w = ww;
		i = ii;
	}

	public int compareTo(Object x) {
		float xw = ((Element) x).w;
		if (w < xw)
			return -1;
		if (w == xw)
			return 0;
		return 1;

	}
	public float getW() {
        return w;
    }
}